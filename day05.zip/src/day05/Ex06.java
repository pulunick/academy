package day05;

public class Ex06 {

	public static void main(String[] args) {
		
		// String.valueOf(...)
		String s1 = String.valueOf(3.14);
		String s2 = String.valueOf('a');
		String s3 = String.valueOf(3 * 2);
		
		//System.out.println();
		System.out.println(true);
		System.out.println(1.2);
		System.out.println("Hello, world !!");

	}

}
