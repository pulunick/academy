package ex02;

public class Main2 {

}
